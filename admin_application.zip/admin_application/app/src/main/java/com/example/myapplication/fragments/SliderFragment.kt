package com.example.myapplication.fragments

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.navigation.ActivityNavigatorExtras
import com.example.myapplication.R
import com.example.myapplication.databinding.FragmentSliderBinding
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import java.util.*

class SliderFragment : Fragment() {

    private lateinit var binding: FragmentSliderBinding
    private var imgUrl : Uri?= null
    private lateinit var dialog : Dialog

    private var lauchGalleryActivity = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ){
        if(it.resultCode == Activity.RESULT_OK){
          imgUrl = it.data!!.data
            binding.imageView.setImageURI((imgUrl))
        }
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentSliderBinding.inflate(layoutInflater)

        dialog = Dialog(requireContext())
        dialog.setContentView(R.layout.progress_layout)
        dialog.setCancelable(false)

        binding.apply {
            imageView.setOnClickListener{
                val intent = Intent("android.intent.action.GET_CONTENT")
                intent.type = "image/*"
                lauchGalleryActivity.launch(intent)
            }

            button5.setOnClickListener{
                if(imgUrl != null){
                    uploadImage(imgUrl!!)
                }
                else{
                    Toast.makeText(requireContext(),"Please select image",Toast.LENGTH_SHORT).show()
                }
            }
        }

        return binding.root
    }

    private fun uploadImage(image: Uri) {
        dialog.show()

        val fileName = UUID.randomUUID().toString()+".jpg"

        val refStorage = FirebaseStorage.getInstance().reference.child("slider/$fileName")
        refStorage.putFile(image)
            .addOnSuccessListener {
                it.storage.downloadUrl.addOnSuccessListener { igname ->
                    storeData(igname.toString())
                }
            }
            .addOnFailureListener{
                dialog.dismiss()
                Toast.makeText(requireContext(),"Something went wrong with storage, ", Toast.LENGTH_SHORT).show()
            }

    }

    private fun storeData( igname: String) {

        val db = Firebase.firestore
        val data = hashMapOf<String,Any>(
            "img" to igname
        )

        db.collection("slider").document("item").set(data)
            .addOnSuccessListener {
                dialog.dismiss()
                Toast.makeText(requireContext(),"Slider Updated", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                dialog.dismiss()
               Toast.makeText(requireContext(),"Something went wrong", Toast.LENGTH_SHORT).show()
            }
    }
}
