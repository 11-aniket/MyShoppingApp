package com.example.myapplication.modal

    class CategoryModal (
        var category: String ? = "",
        var img: String ? = ""
        )
